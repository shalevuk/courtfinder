package com.example.basketballcourts;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.basketballcourts.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Login extends AppCompatActivity implements View.OnClickListener {

    Button loginButton;
    EditText etEmail;
    EditText etPassword;
    Button newUser;

    CheckBox ck;
    SharedPreferences sp;
    FirebaseAuth Auth ;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        loginButton = findViewById(R.id.loginButton);
        loginButton.setOnClickListener(this);
        etEmail = findViewById(R.id.editTextText5);
        etPassword = findViewById(R.id.editTextText6);
        newUser= findViewById(R.id.newUser);
        newUser.setOnClickListener(this);

        ck=findViewById(R.id.checkBox);
        sp = getSharedPreferences("user", 0);
        Auth=FirebaseAuth.getInstance();

    }

    @Override
    public void onClick(View v) {
        if (v == newUser) {
            Intent go=new Intent(Login.this, SignUp.class);
            startActivity(go);

        }
        if (v == loginButton) {
            Auth.signInWithEmailAndPassword(etEmail.getText().toString(), etPassword.getText().toString()).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){//sign in db
                        Toast.makeText(Login.this, "משתמש מחובר!",Toast.LENGTH_LONG).show();
                        firebaseDatabase = FirebaseDatabase.getInstance();
                        //גישה לתת הענף של Users
                        myRef=firebaseDatabase.getReference("Users").child(etEmail.getText().toString().replace(".", " "));
                        myRef.addValueEventListener(new ValueEventListener() {

                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                // for(DataSnapshot singleSnapshot : snapshot.getChildren()) {
                                //  u = new User(singleSnapshot.child("name").getValue().toString(),
                                //          singleSnapshot.child("email").getValue().toString(), singleSnapshot.child("pass").getValue().toString());
                                User u = snapshot.getValue(User.class);
                                Toast.makeText(Login.this, u.getName(), Toast.LENGTH_LONG).show();
                                SharedPreferences.Editor edit = sp.edit();
                                edit.putString("name", u.getName());
                                edit.putString("email", u.getEmail());
                                edit.putString("number", u.getPhone());
                                edit.putString("pass", u.getPass());
                                edit.putString("picture",u.getPicture());
                                edit.putBoolean("isChecked", ck.isChecked());
                                edit.commit();


                               Intent go=new Intent(Login.this, MapsActivity.class);
                               startActivity(go);

                            }


                            @Override
                            public void onCancelled(DatabaseError databaseError) {
                                Toast.makeText(Login.this, ""+databaseError.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        });

                    }

                }

            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {

                    Toast.makeText(Login.this, "user not found", Toast.LENGTH_LONG).show();

                }
            });
        }
    }
}