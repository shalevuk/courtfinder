package com.example.basketballcourts;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link gps2#newInstance} factory method to
 * create an instance of this fragment.
 */
public class gps2 extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    Button btnGeo;
    private String mParam2;
    TextView et4,et5;

    public gps2() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment gps2.
     */
    // TODO: Rename and change types and number of parameters
    public static gps2 newInstance(String param1, String param2) {
        gps2 fragment = new gps2();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View view =inflater.inflate(R.layout.fragment_gps2,container,false);
        btnGeo=view.findViewById(R.id.btnGeo);
        btnGeo.setOnClickListener(new View.OnClickListener() {
                                      @Override
            public void onClick(View v) {

                                          et4=view.findViewById(R.id.et4); //אני גאונה
                                          et5=view.findViewById(R.id.et5);
                                          String geoUriString = "geo: "+et4.getText().toString()+", "+et5.getText().toString()+"?z=13";
                                          Uri geoUri = Uri.parse(geoUriString);
                                          Intent map = new Intent(Intent.ACTION_VIEW, geoUri);
                                          startActivity(map);
                                      }
                                  });
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_gps2, container, false);
    }
}