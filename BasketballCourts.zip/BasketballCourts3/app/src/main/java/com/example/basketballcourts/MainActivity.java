package com.example.basketballcourts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private ImageView img;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        img = findViewById(R.id.imageView);
        sp=getSharedPreferences("user", 0);

        Thread splash = new Thread() {
            public void run() {
                try {
                    synchronized (this) {
                        MediaPlayer music = MediaPlayer.create(MainActivity.this, R.raw.sound2opening);
                        music.start();
                        Animation anim = AnimationUtils.loadAnimation(MainActivity.this, R.anim.tween);
                        img.startAnimation(anim);
                        wait(5000);
                    }
                } catch (InterruptedException ex) {

                }
               // boolean flag = sp.getBoolean("isChecked", false);
                Intent go;
               // if (flag) {
                    go = new Intent(MainActivity.this, HomePage.class);
               // } else {
                //    go = new Intent(MainActivity.this, Login.class);
               // }
                startActivity(go);
                finish();
            }
        };
        splash.start();
    }
}
