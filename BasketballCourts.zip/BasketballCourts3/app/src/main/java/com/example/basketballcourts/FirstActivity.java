package com.example.basketballcourts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FirstActivity extends AppCompatActivity {
    Button btnAdr;
    TextView et1,et2,et3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        btnAdr=findViewById(R.id.btnAdr);
        btnAdr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String e1=et1.getText().toString();
                String e3=et3.getText().toString();
                String e2=et2.getText().toString();
                String geoUriString="geo:0,0?q="+et1+","+et2+","+et3+"&z=15";
                Uri geoUri=Uri.parse(geoUriString);
                Intent map= new Intent(Intent.ACTION_VIEW,geoUri);
                startActivity(map);
            }
        });

    }
}