package com.example.basketballcourts.;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CourtAdapter extends RecyclerView.Adapter<CourtAdapter.MyViewHolder>
{
    ArrayList<Courts> courts;
    Context context;

    public CourtAdapter(Context context, ArrayList<Courts> allCourts) {
        this.context=context;
        this.courts=allCourts;
    }


    @NonNull

    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // infalte the item Layout
        LayoutInflater layoutInflater= LayoutInflater.from(parent.getContext());
        View view=layoutInflater.inflate(R.layout.court_sample, parent, false);
        MyViewHolder myViewHolder=new MyViewHolder(view);
        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        // set the data in items
        holder.courtName.setText(courts.get(position).getName());
        holder.courtName.setText(courts.get(position).getCity());
        holder.mail.setText(courts.get(position).getEmail());

        /*holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                adb = new AlertDialog.Builder(context);
                adb.setTitle("Time To Train!");
                adb.setMessage("Study " + kanjis.get(position).getKanji() + "?");
                adb.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent intent = new Intent(context, TrainScreen.class);
                        intent.putExtra("kanji", kanjis.get(position));
                        context.startActivity(intent);
                    }
                });
                adb.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                    }
                });
                ad = adb.create();
                ad.show();
            }
        });

         */
    }


    public int getItemCount() {
        return courts.size();
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView courtName;
        public TextView courtCity;
        public TextView mail;
        Button mapsBtn;
        Button phoneBtn;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            courtName=itemView.findViewById(R.id.court_name_tv);
            courtCity = itemView.findViewById(R.id.court_city_tv);
            mail = itemView.findViewById(R.id.court_mail);
            mapsBtn = itemView.findViewById(R.id.court_maps_btn);
            phoneBtn = itemView.findViewById(R.id.court_phone_btn);
        }
    }
}