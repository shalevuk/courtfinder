package com.example.basketballcourts;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Search extends Fragment {

    private RecyclerView recyclerView;
    private ArrayAdapter<Courts> recyclerCourtsList;
    private ArrayList<Courts> courtsList;
    private ArrayList<String> cities;
    TextView filter;
    ArrayList<Integer> cList ;
    boolean[] selectedCities;
    String [] sCities;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_search, container, false);
        cities = new ArrayList<>();
        courtsList = new ArrayList<>();
        cList = new ArrayList<>();
        FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
        DatabaseReference db = firebaseDatabase.getReference("courts");
        db.get().addOnSuccessListener(new OnSuccessListener<DataSnapshot>() {
            @Override
            public void onSuccess(DataSnapshot dataSnapshot) {
                for (DataSnapshot ds: dataSnapshot.getChildren()){
                    cities.add(ds.getKey());
                    courtsList.add(ds.getValue(Courts.class));
                }
                selectedCities= new boolean[cities.size()];
                createFrag();
            }
        });

        return view;
    }
    private void createFrag()
    {
        recyclerCourtsList = new ArrayList<>();
        sCities = new String[cities.size()];
        sCities = cities.toArray(sCities);

        // Initialize ListView and ArrayAdapter
       /* listViewCourts = view.findViewById(R.id.listViewCourts);
        courtsList = new ArrayList<Courts>();
        adapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, courtsList);

        // Sample data - replace with your data
       Courts[] sampleCourts = {"Court 1", "Court 2", "Court 3"};
        courtsList.addAll(Arrays.asList(sampleCourts));
        // Set adapter to ListView
        listViewCourts.setAdapter(adapter);*/
        filter = getView().findViewById(R.id.filter);
        filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Initialize alert dialog
                AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

                // set title
                builder.setTitle("Select City");

                // set dialog non cancelable
                builder.setCancelable(false);

                builder.setMultiChoiceItems(sCities, selectedCities, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i, boolean b) {
                        // check condition
                        if (b) {
                            // when checkbox selected
                            // Add position  in lang list
                            cList.add(i);
                            // Sort array list
                            Collections.sort(cList);
                        } else {
                            // when checkbox unselected
                            // Remove position from langList
                            cList.remove(Integer.valueOf(i));
                        }
                    }
                });

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Initialize string builder
                        StringBuilder stringBuilder = new StringBuilder();
                        // use for loop
                        for (int j = 0; j < cList.size(); j++) {
                            // concat array value
                            stringBuilder.append(cities.toArray()[cList.get(j)]);
                            recyclerCourtsList.add(courtsList.get(cList.get(j)));
                            // check condition
                            if (j != cList.size() - 1) {
                                // When j value  not equal
                                // to lang list size - 1
                                // add comma
                                stringBuilder.append(", ");
                            }
                        }
                        recyclerView = getView().findViewById(R.id.search_recycler);
                        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getContext());
                        recyclerView.setLayoutManager(layoutManager);
                        CourtAdapter courtAdapter = new CourtAdapter(getContext(), recyclerCourtsList);
                        recyclerView.setAdapter(courtAdapter);
                        // set text on textView
                        filter.setText(stringBuilder.toString());
                    }
                });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // dismiss dialog
                        dialogInterface.dismiss();
                    }
                });
                builder.setNeutralButton("Clear All", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // use for loop
                        for (int j = 0; j < selectedCities.length; j++) {
                            // remove all selection
                            selectedCities[j] = false;
                            // clear language list
                            cList.clear();
                            // clear text view value
                            filter.setText("");
                        }
                    }
                });
                // show dialog
                builder.show();
            }
        });
    }
}
