package com.example.basketballcourts;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.basketballcourts.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;

public class SignUp extends AppCompatActivity implements View.OnClickListener {

    EditText etUserName;
    EditText etPassword;
    EditText etEmail;
    EditText etNumber;

    Button submitButton;
    ImageView profileImage;
    Uri uri;
    AlertDialog.Builder adb;
    AlertDialog ad;
    private static final int MY_CAMERA_REQUEST_CODE = 100;
    String picture="";
    String fromCamera="";
    ActivityResultLauncher activityResultLauncher;
    int flag;
    byte[] bytes;

    SharedPreferences sp;
    FirebaseDatabase firebaseDatabase;
    FirebaseAuth firebaseAuth;
    DatabaseReference myref;
    Intent go;
    String picName="";
    StorageReference mStorageRef;
    private static final int FROM_GALLERY = 1;
    private static final int FROM_CAMERA = 2;
    boolean f=false;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);


        sp = getSharedPreferences("user", 0);
        etUserName=findViewById(R.id.editTextText1);
        etPassword=findViewById(R.id.editTextText2);
        etEmail=findViewById(R.id.editTextText3);
        etNumber=findViewById(R.id.editTextText4);

        firebaseDatabase = FirebaseDatabase.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();

        submitButton=findViewById(R.id.submitButton);
        submitButton.setOnClickListener(this);
        profileImage = findViewById(R.id.imageView);
        profileImage.setOnClickListener(this);
        activityResultLauncher= registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {


                        if (result.getData()!=null && result.getData().getAction()==null &&result.getResultCode() == Activity.RESULT_OK) {
                            Intent data = result.getData();
                            uri = data.getData();
                            profileImage.setImageURI(uri);
                            picName=System.currentTimeMillis() + "."+ getFileExtension(uri);
                            Toast.makeText(SignUp.this, picName, Toast.LENGTH_LONG).show();
                            flag=FROM_GALLERY;
                            f= true;//boolean if must enter picture


                        }


                        else if (result.getData()!=null   && result.getResultCode() == Activity.RESULT_OK) {
                            Bitmap bitmap = (Bitmap) result.getData().getExtras().get("data");


                            picName=System.currentTimeMillis() + "."+ "jpg";
                            Toast.makeText(SignUp.this, picName, Toast.LENGTH_LONG).show();

                            profileImage.setImageBitmap(bitmap);
                            ByteArrayOutputStream baos = new ByteArrayOutputStream();
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                            bytes = baos.toByteArray();
                            flag=FROM_CAMERA;
                            f= true;


                        }
                    }
                });


    }

    private String getFileExtension(Uri uri) {
        ContentResolver cR = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cR.getType(uri));
    }
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_CAMERA_REQUEST_CODE)
        {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                Toast.makeText(SignUp.this, "camera permission granted", Toast.LENGTH_LONG).show();
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                activityResultLauncher.launch(cameraIntent);
            }
            else
            {
                Toast.makeText(SignUp.this, "camera permission denied", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onClick(View view) {
        if (profileImage == view) {
            adb = new AlertDialog.Builder(this);
            adb.setTitle("pick picture");
            adb.setMessage("choose picture from gallery/camera");

            adb.setCancelable(true);
            adb.setPositiveButton("גלריה", new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface d, int i) {
                    Intent intent = new Intent();
                    intent.setType("image/*");
                    intent.setAction(Intent.ACTION_OPEN_DOCUMENT);
                    activityResultLauncher.launch(intent);
                }
            });
            adb.setNeutralButton("מצלמה", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface d, int i) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED) {
                        if (ActivityCompat.checkSelfPermission(SignUp.this, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(new String[]{android.Manifest.permission.CAMERA}, MY_CAMERA_REQUEST_CODE);
                        }
                    }
                    else {
                        Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                        activityResultLauncher.launch(intent);
                    }
                }
            });
            ad = adb.create();
            ad.show();
        }
        if(view==submitButton)
        {
            createUser();
        }

/*
        if(view==submitButton)
        {


            User u=new User(et1.getText().toString(),et2.getText().toString(),et3.getText().toString(),et4.getText().toString(),picture,fromCamera);
            myDb=new DbHelper(this);
            int i= myDb.insert(this,u);

            if(i==1)
            {
                SharedPreferences.Editor edit = sp.edit();
                edit.putString("name", et1.getText().toString());
                edit.putString("pass", et2.getText().toString());
                edit.putBoolean("isChecked", ck.isChecked());
                edit.commit();
                Intent go=new Intent(this, FirstActivity.class);
                startActivity(go);

            }
            finish();

        }

 */

    }


    public void createUser() {
        if (!f){
            Toast.makeText(SignUp.this, "must enter a picture", Toast.LENGTH_LONG).show();

        }else {



            myref = firebaseDatabase.getReference("Users");
            firebaseAuth.createUserWithEmailAndPassword(etEmail.getText().toString(), etPassword.getText().toString()).addOnCompleteListener(this,
                    new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {

                                //יצירת אובייקט מסוג User
                                User u = new User(etUserName.getText().toString(), etPassword.getText().toString(), etEmail.getText().toString(), etNumber.getText().toString(), picName);
                                // myref.push().setValue(u);
                                myref = myref.child(etEmail.getText().toString().replace(".", " "));
                                myref.setValue(u);

                                if (flag == FROM_GALLERY) {
                                    mStorageRef = FirebaseStorage.getInstance().getReference("Images/Users/" + etEmail.getText().toString().replace('.', ' '));
                                    mStorageRef = mStorageRef.child(picName);
                                    Toast.makeText(SignUp.this, "input1", Toast.LENGTH_LONG).show();

                                    mStorageRef.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {

                                        @Override
                                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                            Toast.makeText(SignUp.this, "תמונה הועלתה", Toast.LENGTH_LONG).show();
                                            Toast.makeText(SignUp.this, "ההרשמה הצליחה, כעת ניתן להתחבר!", Toast.LENGTH_LONG).show();
                                            //עושה לי שגיאה אם אני רושמת את זה
                                            go = new Intent(SignUp.this, FirstActivity.class);
                                            startActivity(go);
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {

                                            Toast.makeText(SignUp.this, "" + e.getMessage(), Toast.LENGTH_LONG).show();
                                        }
                                    });
                                } else {
                                    mStorageRef = FirebaseStorage.getInstance().getReference("Images/Users/" + etEmail.getText().toString().replace('.', ' '));
                                    mStorageRef = mStorageRef.child(picName);
                                    Toast.makeText(SignUp.this, "input1", Toast.LENGTH_LONG).show();

                                    UploadTask uploadTask = mStorageRef.putBytes(bytes);
                                    uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                        @Override
                                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                            Toast.makeText(SignUp.this, "תמונה הועלתה", Toast.LENGTH_LONG).show();
                                            Toast.makeText(SignUp.this, "ההרשמה הצליחה, כעת ניתן להתחבר!", Toast.LENGTH_LONG).show();
                                            //עושה לי שגיאה אם אני רושמת את זה
                                            go = new Intent(SignUp.this, FirstActivity.class);
                                            startActivity(go);
                                        }
                                    }).addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {

                                            Toast.makeText(SignUp.this, "" + e.getMessage(), Toast.LENGTH_LONG).show();
                                        }
                                    });

                                }






                            }

                        }

                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {

                    Toast.makeText(SignUp.this, "" + e.getMessage(), Toast.LENGTH_LONG).show();
                    // p.dismiss();
                }
            });
        }
    }

}